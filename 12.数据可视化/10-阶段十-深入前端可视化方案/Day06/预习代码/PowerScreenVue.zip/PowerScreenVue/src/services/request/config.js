export const BASE_URL = "http://123.207.32.32:9060/beike/api"
export const TIMEOUT = 10000
